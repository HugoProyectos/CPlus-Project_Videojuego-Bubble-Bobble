/*
* 
* Practica_02_base.js
* Videojuegos (30262) - Curso 2019-2020
* 
* Parte adaptada de: Alex Clarke, 2016, y Ed Angel, 2015.
* 
*/

// Variable to store the WebGL rendering context
var gl;

//----------------------------------------------------------------------------
// OTHER DATA 
//----------------------------------------------------------------------------

var model = new mat4();   		// create a model matrix and set it to the identity matrix
var view = new mat4();   		// create a view matrix and set it to the identity matrix
var projection = new mat4();	// create a projection matrix and set it to the identity matrix

var eye, target, up;			// for view matrix

var planeProgramInfo = {
	program: {},
	uniformLocations: {},
	attribLocations: {},
};

var sphereProgramInfo = {
	program: {},
	uniformLocations: {},
	attribLocations: {},
};

// List of objects to draw
var objectsToDraw = [
	{
		programInfo: planeProgramInfo,
		pointsArray: pointsPlane, 
		uniforms: {
			u_color: [1.0, 1.0, 1.0, 1.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	 },
	 /*{	programInfo: planeProgramInfo,
	 	pointsArray: pointsPlane2,
	 	uniforms: {
	 		u_color: [1.0, 1.0, 1.0, 1.0],
	 		u_model: new mat4(),
	 	},
	 	primType: "triangles",
	 },
	 {	programInfo: planeProgramInfo,
	 	pointsArray: pointsPlane3,
	 	uniforms: {
	 		u_color: [1.0, 1.0, 1.0, 1.0],
	 		u_model: new mat4(),
	 	},
	 	primType: "triangles",
	 },
	 {	programInfo: planeProgramInfo,
	 	pointsArray: pointsPlane4,
	 	uniforms: {
	 		u_color: [1.0, 1.0, 1.0, 1.0],
	 		u_model: new mat4(),
	 	},
	 	primType: "triangles",
	},*/
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [1.0, 1.0, 1.0, 1.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
    {
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
	{
		programInfo: sphereProgramInfo,
		pointsArray: pointsSphere, 
		uniforms: {
			u_color: [8.0, 4.0, 0.1, 3.0],
			u_model: new mat4(),
		},
		primType: "triangles",
	},
];

// List of spheres with their current state
var spheres = [
	{
		position: [-3.0, -3.0, 2.0],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.5 / 2,
	},
	{
		position: [-8.5, -8.5, 1.5 / 2],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [8.5, -8.5, 1.5 / 2],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [0.0, 0, 15.0],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [24.5, 0.0, 1.5 / 2] ,
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [-19, 19.0, 1.5 / 2],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [-8.5, 8.5, 1.5 / 2],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
    {
		position: [8.5, 8.5, 1.5 / 2],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [-18.5, 0.0, 5.0],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [-5.0, -12.5, 7],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
	{
		position: [5.0, -12.5, 7],
		rotation: [0.0, 0.0, 0.0],
		prevRotation: vec3(1.0, 0.0, 0.0),
		velocity: [0.0, 0.0, 0.0],
		radius: 1.0 / 2,
	},
]

//----------------------------------------------------------------------------
// Initialization function
//----------------------------------------------------------------------------

window.onload = function init() {
	
	// Set up a WebGL Rendering Context in an HTML5 Canvas
	var canvas = document.getElementById("gl-canvas");
	gl = WebGLUtils.setupWebGL(canvas);
	if (!gl) {
		alert("WebGL isn't available");
	}

	//  Configure WebGL
	gl.clearColor(0.0, 0.0, 0.0, 1.0);
	gl.enable(gl.DEPTH_TEST);
	gl.disable(gl.CULL_FACE);

	setPrimitive(objectsToDraw);

	// Set up a WebGL program for the plane
	// Load shaders and initialize attribute buffers
	planeProgramInfo.program = initShaders(gl, "plane-vertex-shader", "plane-fragment-shader");
	  
	// Save the attribute and uniform locations
	planeProgramInfo.uniformLocations.model = gl.getUniformLocation(planeProgramInfo.program, "model");
	planeProgramInfo.uniformLocations.view = gl.getUniformLocation(planeProgramInfo.program, "view");
	planeProgramInfo.uniformLocations.projection = gl.getUniformLocation(planeProgramInfo.program, "projection");
	planeProgramInfo.uniformLocations.baseColor = gl.getUniformLocation(planeProgramInfo.program, "baseColor");
	planeProgramInfo.attribLocations.vPosition = gl.getAttribLocation(planeProgramInfo.program, "vPosition");

	// Set up a WebGL program for spheres
	// Load shaders and initialize attribute buffers
	sphereProgramInfo.program = initShaders(gl, "sphere-vertex-shader", "sphere-fragment-shader");
	  
	// Save the attribute and uniform locations
	sphereProgramInfo.uniformLocations.model = gl.getUniformLocation(sphereProgramInfo.program, "model");
	sphereProgramInfo.uniformLocations.view = gl.getUniformLocation(sphereProgramInfo.program, "view");
	sphereProgramInfo.uniformLocations.projection = gl.getUniformLocation(sphereProgramInfo.program, "projection");
	sphereProgramInfo.uniformLocations.baseColor = gl.getUniformLocation(sphereProgramInfo.program, "baseColor");
	sphereProgramInfo.attribLocations.vPosition = gl.getAttribLocation(sphereProgramInfo.program, "vPosition");

	// Set up viewport 
	gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);

	angle = 0;
    radius = 10;
    
	eye = vec3(10.0, 0.0, radius);
	target = vec3(0.0, 0.0, 0.0);
	up = vec3(0.0, 0.0, 1.0 );

	// Set initial positions
	spheres.forEach(function(sphere, index) {
		// sphere.position = [5*(2*Math.random() - 1), 5*(2*Math.random() - 1),  5*(2*Math.random() - 1) + 5];
		//sphere.position = [5*(2*Math.random() - 1), 5*(2*Math.random() - 1), 3*(2*Math.random()) + 3];
		// console.log(sphere.position)
		//sphere.rotation = [0, 0, 0];
		//sphere.velocity = [5*(2*Math.random() - 1),5*(2*Math.random() - 1), 0];
		/*spheres.forEach(function(sphere2, index2) {
			if(index != index2){
				distance = Math.sqrt(Math.pow(spheres[index].position[0] - spheres[index2].position[0],2) + Math.pow(spheres[index].position[1] - spheres[index2].position[1],2) + Math.pow(spheres[index].position[2] - spheres[index2].position[2],2));
				while(distance <= 3.5){
						// console.log(distance);
						sphere.position[0] += 1.5;
						sphere.position[1] += 1.5;
						sphere.position[2] += 1.5;
						distance = Math.sqrt(Math.pow(spheres[index].position[0] - spheres[index2].position[0],2) + Math.pow(spheres[index].position[1] - spheres[index2].position[1],2) + Math.pow(spheres[index].position[2] - spheres[index2].position[2],2));
                }
            }
		});*/
	
	});

    saltoDisponible = true;
    noRebotar = false;

	maxX = 0;
	minX = 0;
	maxY = 0;
	minY = 0;

	for (var i = 0; i<6; i++) {
		if (objectsToDraw[0].pointsArray[i][0] > maxX){
			maxX = objectsToDraw[0].pointsArray[i][0];
		} else if (objectsToDraw[0].pointsArray[i][0] < minX) {
			minX = objectsToDraw[0].pointsArray[i][0];
		}
	}

	for (var i = 0; i<6; i++) {
		if (objectsToDraw[0].pointsArray[i][1] > maxY){
			maxY = objectsToDraw[0].pointsArray[i][1];
		} else if(objectsToDraw[0].pointsArray[i][1] < minY){
			minY = objectsToDraw[0].pointsArray[i][1];
		}
	}

	spheres[0].position = [0.0, 0.0, spheres[0].radius/2.0 + 3];

	//spheres[0].position = [5*(2*Math.random() - 1),5*(2*Math.random() - 1), spheres[0].radius/2.0];
	//spheres[0].velocity = [5*(2*Math.random() - 1),5*(2*Math.random() - 1), 0];

	window.addEventListener("keydown", function(event){
		if (event.key == 'd') { // right arrow
			x_aux = target[0] - eye[0]
            y_aux = target[1] - eye[1]
            modulo = Math.sqrt(Math.pow(x_aux,2) + Math.pow(y_aux,2))
			
				spheres[0].velocity[1] -= x_aux/ modulo * 2
                
				spheres[0].velocity[0] += y_aux/modulo * 2
                
                
                //console.log('derecha')
                //console.log(spheres[0].velocity)
        }
        if (event.key == 'a') { // left arrow
			x_aux = target[0] - eye[0]
            y_aux = target[1] - eye[1]
            modulo = Math.sqrt(Math.pow(x_aux,2) + Math.pow(y_aux,2))
			
				spheres[0].velocity[1] += x_aux/ modulo * 2
                
				spheres[0].velocity[0] -= y_aux/modulo * 2
                
                
                
                //console.log('izquierda')
                //console.log(spheres[0].velocity)
        } 
        if (event.key == 'w') { // up arrow
			x_aux = target[0] - eye[0]
            y_aux = target[1] - eye[1]
            modulo = Math.sqrt(Math.pow(x_aux,2) + Math.pow(y_aux,2))
			
				spheres[0].velocity[0] += x_aux/ modulo * 2
                
				spheres[0].velocity[1] += y_aux/modulo * 2
                
                
                //console.log('arriba')
                //console.log(spheres[0].velocity)
        } 
        if (event.key == 's') { // down arrow
			x_aux = target[0] - eye[0]
            y_aux = target[1] - eye[1]
            modulo = Math.sqrt(Math.pow(x_aux,2) + Math.pow(y_aux,2))
			
				spheres[0].velocity[0] -= x_aux/ modulo * 2
                
				spheres[0].velocity[1] -= y_aux/modulo * 2
                
                
                //console.log('abajo')
                //console.log(spheres[0].velocity)
        } 
        if (event.key == 'q') { // rotate left
			angle += 0.05
			console.log(angle)
            if (angle >= 360){
                angle -= 360
            }else if (angle<= -360){
                angle += 360
            }
                
                
                //console.log('arriba')
                //console.log(spheres[0].velocity)
        } 
        if (event.key == 'e') { // rotate right
			angle -= 0.05
            if (angle >= 360){
                angle -= 360
            }else if (angle <= -360){
                angle += 360
            }
                //console.log('abajo')
                //console.log(spheres[0].velocity)
        } 
        if (event.key == ' ') { // down arrow
            if (saltoDisponible) {
                saltoDisponible = false;
                spheres[0].velocity[2] += 10.0
            }
            
            
            
        } 
        if (event.keyCode == 16) { // left shift
            noRebotar = true
        }
        
        vMax = 5
        if (spheres[0].velocity[0] < -vMax){
            spheres[0].velocity[0] = -vMax
        }else if (spheres[0].velocity[0] > vMax){
            spheres[0].velocity[0] = vMax
        }
        
        if (spheres[0].velocity[1] < -vMax){
            spheres[0].velocity[1] = -vMax
        }else if (spheres[0].velocity[1] > vMax){
            spheres[0].velocity[1] = vMax
        }
        
	})
    
	let lastMouseX = 0;
    let lastMouseY = 0;
    let isDragging = false;
	let v = 0.5 // factor de velocidad movimiento
    let dx = 0
    let dy = 0
    
    window.addEventListener('mousedown', function(event) {
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
        isDragging = true;
    });
    
    window.addEventListener('mousemove', function(event) {
        if (isDragging) {
			mouseX = event.clientX
			mouseY = event.clientY
            dx = (mouseX - lastMouseX)
			dy = (mouseY - lastMouseY)
			lastMouseX = mouseX
			lastMouseY = mouseY
			
			//eye[1] += dx
			//eye[0] += dy
            
            angle -= dx/100
            if (angle >= 360){
                angle -= 360
            }else if (angle <= -360){
                angle += 360
            }
            radius -= dy/10;
            if (radius < 5) {
                radius = 5
            }
            
        }
    });
    
    window.addEventListener('mouseup', function() {
        isDragging = false;
    });
    
    counter = 0
    vidas_extra = 2
    tiempoTotal = 120
    gameOver = false
    pararTiempo  = false
	
	lastTick = Date.now();
	requestAnimFrame(tick);
};

//----------------------------------------------------------------------------
// Tick Event Function
//----------------------------------------------------------------------------

var lastTick;

function tick(nowish) {
	var now = Date.now();

    var dt = now - lastTick;
    lastTick = now;

	update(dt)
	render(dt)

	window.requestAnimationFrame(tick)
}

//----------------------------------------------------------------------------
// Update Event Function
//----------------------------------------------------------------------------

function update(dt) {
	// Update state
	let normalPlano = vec3(0.0, 0.0, 1.0);
	spheres.forEach(function(sphere, index) {
		// // Update state (rotation) of the sphere1
		// sphere.rotation[0] = (sphere.rotation[0] + sphere.velocity[1]*dt/6.28) % 360;
		// sphere.rotation[1] = (sphere.rotation[1] + sphere.velocity[0]*dt/6.28) % 360;
		
		// Update graphical representation
		let transform = scale(sphere.radius * 2, sphere.radius * 2, sphere.radius* 2);

		//Rotacion
		var vecVel = vec3(sphere.velocity[0],sphere.velocity[1],0);
		var linVel = length(vecVel);
		if(index == 0){
			console.log(linVel);
		}
		if(!(Math.abs(sphere.velocity[0]) <= 0.005) || !(Math.abs(sphere.velocity[1]) <= 0.005)){
			//transform = mult(rotate(linVel, cross(normalPlano,vecVel)), transform);
			sphere.rotation[0] = (sphere.rotation[0] + linVel)%360;
			//sphere.rotation[0] = (linVel * 1000);
			sphere.prevRotation = cross(normalPlano,normalize(vecVel));
			transform = mult(rotate(sphere.rotation[0], cross(normalPlano,normalize(vecVel))),transform);
		} else {
			transform = mult(rotate(sphere.rotation[0], sphere.prevRotation),transform);
		}

		transform = mult(translate(sphere.position[0], sphere.position[1], sphere.position[2]), transform);

		// Colision con esferas
        if (index == 0) {
            spheres.forEach(function(sphereColl, indice){
                if(indice != index){
                    const a = vec3(sphere.position);
                    const b = vec3(sphereColl.position);
                    distance = Math.sqrt(Math.pow(b[0] - a[0],2) + Math.pow(b[1] - a[1],2) + Math.pow(b[2] - a[2],2));
                    if(Math.abs(distance) <= sphere.radius + sphereColl.radius){
                        sphereColl.position[0] = 10.0
                        sphereColl.position[1] = 10.0
                        sphereColl.position[2] = 100.0
                        
                        counter++;
                        document.getElementById('counter').innerHTML = 'Puntuacion: ' + counter + ' / 10';
                        
                        if (counter >= 10 && pararTiempo == false) {
                            document.getElementById('victoria').innerHTML = '¡GANASTE! \n tiempo restante: ' + tiempoTotal.toFixed(2);
                            document.getElementById('victoria').style.display = "block";
                            pararTiempo = true
                        }
                    }
                }
            })
        }
        
        if (index == 0) {
            gravity = [0,0,-9.8];
            sphere.velocity[2] = sphere.velocity[2] + (gravity[2])*(dt/1000);
            next_position_z = sphere.position[2] + sphere.velocity[2]*(dt/1000);
            next_position_y = sphere.position[1] + sphere.velocity[1]*(dt/1000);
            next_position_x = sphere.position[0] + sphere.velocity[0]*(dt/1000);
            
            // colision plano principal
            dentro1 = (sphere.position[0] < 10) && (sphere.position[0] > -10) && (sphere.position[1] < 10) && (sphere.position[1] > -10) && (next_position_z <= objectsToDraw[0].pointsArray[2][2] + sphere.radius) && (sphere.position[2] >= objectsToDraw[0].pointsArray[2][2] + sphere.radius);
            
            // colision plano rectangular
            dentro2 = (sphere.position[0] < 10) && (sphere.position[0] > -10) && (sphere.position[1] < -15) && (sphere.position[1] > -20) && (next_position_z <= objectsToDraw[0].pointsArray[2][2] + sphere.radius) && (sphere.position[2] >= objectsToDraw[0].pointsArray[2][2] + sphere.radius);
            
            // colision plano cuadrado de al lado
            dentro3 = (sphere.position[0] < 16) && (sphere.position[0] > 10) && (sphere.position[1] < 3) && (sphere.position[1] > -3) && (next_position_z <= objectsToDraw[0].pointsArray[2][2] + sphere.radius) && (sphere.position[2] >= objectsToDraw[0].pointsArray[2][2] + sphere.radius);
            
            // colision plano rectangular al lado del cuadrado
            dentro4 = (sphere.position[0] < 26) && (sphere.position[0] > 16) && (sphere.position[1] < 1) && (sphere.position[1] > -1) && (next_position_z <= objectsToDraw[0].pointsArray[2][2] + sphere.radius) && (sphere.position[2] >= objectsToDraw[0].pointsArray[2][2] + sphere.radius);
            
            // colision plano que está encima
            dentro5 = (sphere.position[0] < 3) && (sphere.position[0] > -3) && (sphere.position[1] < 3) && (sphere.position[1] > -3) && (sphere.position[2] >= 7 + sphere.radius) && (next_position_z <= 7 + 1.5) ;
            
            // colision plano que está encima desde abajo
            dentro6 = (sphere.position[0] < 3) && (sphere.position[0] > -3) && (sphere.position[1] < 3) && (sphere.position[1] > -3) && (sphere.position[2] <= 7 - sphere.radius) && (next_position_z >= 7 - 1.5) ;
            
            // colision plano diagonal
            dentro7 = (sphere.position[0] < -9) && (sphere.position[0] > -20) && (sphere.position[1] < 20) && (sphere.position[1] > 9) && (next_position_z <= objectsToDraw[0].pointsArray[2][2] + sphere.radius) && Math.abs(Math.abs(sphere.position[0]) - Math.abs(sphere.position[1])) <= 1 && (sphere.position[2] >= objectsToDraw[0].pointsArray[2][2] + sphere.radius);
            
            // colision plano inclinado
            m = (5-0)/(-20 - -10)
            b = -5
            dentro8 = (sphere.position[0] < -10) && (sphere.position[0] > -20) && (sphere.position[1] < 1) && (sphere.position[1] > -1) && (next_position_z <= (m * sphere.position[0] + b) + sphere.radius);
            
            rebote_suelo =(dentro1 || dentro2 || dentro3 || dentro4 || dentro5 || dentro6 || dentro7 || dentro8) 
            
            rebote_pared =  (sphere.position[2] < 5) && (sphere.position[2] > 0) && (sphere.position[0] < 10) && (sphere.position[0] > -10) && (next_position_y <= -20 + sphere.radius) && (sphere.position[1] >= -20 + sphere.radius);
            
            if (rebote_pared){
                sphere.velocity[1] = -sphere.velocity[1]
                // Aplicar friccion
                for (let i = 0; i < 3; i++) {
                    sphere.velocity[i] = sphere.velocity[i] * 0.99
                    if (sphere.velocity[i] < 0.5  && sphere.velocity[i] > -0.01) {
                        sphere.velocity[i] = 0
                    }
                }
            }
            
            if(rebote_suelo){
                
                sphere.velocity[2] = -sphere.velocity[2]/*/1.5*/;
                // hacer que suba por el plano inclinado
                if (dentro8) {
                    sphere.position[2] = (m * sphere.position[0] + b) + sphere.radius
                    sphere.velocity[0] += 0.66
                    sphere.velocity[2] += 0.33
                }
                // Si tocamos el suelo se puede saltar
                if (!dentro6) {
                    saltoDisponible = true;
                }
                // Aplicar friccion
                for (let i = 0; i < 3; i++) {
                    sphere.velocity[i] = sphere.velocity[i] * 0.9
                    if (sphere.velocity[i] < 0.5  && sphere.velocity[i] > -0.01) {
                        sphere.velocity[i] = 0
                    }
                }
                if (noRebotar == true){
                    sphere.velocity[2] = 0
                    noRebotar = false
                }
                
            }
            else{
                sphere.position[2] += sphere.velocity[2]*(dt/1000);
            }
            sphere.position[0] += sphere.velocity[0]*(dt/1000);
            sphere.position[1] += sphere.velocity[1]*(dt/1000);
            
            if (next_position_z <= - 10) {
                if (vidas_extra == 0) {
                    location.reload()
                }else {
                    vidas_extra --
                }
                
                document.getElementById('vidas').innerHTML = 'Vidas extra: ' + vidas_extra;
                sphere.position = [5*(2*Math.random() - 1), 5*(2*Math.random() - 1), 3*(2*Math.random()) + 3];
                // console.log(sphere.position)
                sphere.rotation = [0, 0, 0];
                sphere.velocity = [5*(2*Math.random() - 1),5*(2*Math.random() - 1), 0];
            }
        }
		

		//sphere.tiempo += (dt/1000);

		if (index == 0) {
            target = vec3(sphere.position[0], sphere.position[1], sphere.position[2]);
            
            
            var y = target[1] + radius * Math.sin(angle); // Calcular la nueva posición en Y
            var z = target[2] + 1; // La posición en Z no cambia
            var x = target[0] + radius * Math.cos(angle); // Calcular la nueva posición en X
            
            eye = vec3(x, y, z); // Actualizar la posición de la cámara
		}
		
		if (sphere.velocity[1] != 0){
			sphere.rotation[0] += (sphere.velocity[1] *  dt/(2*3.14));	
		}
		if (sphere.velocity[0] != 0){
			sphere.rotation[1] += (sphere.velocity[0] *  dt/(2*3.14));
		} 

		// sphere.rotation += [sphere.velocity[0] *  dt/(2*3.14), sphere.velocity[1] *  dt/(2*3.14), sphere.velocity[2] *  dt/(2*3.14)]
		// Skip the plane

		// COLISION ESFERA ESFERA ------------------------------------------------------

		// for 

		// -----------------------------------------------------------------------------
		index += 1;

		objectsToDraw[index].uniforms.u_model = transform;
	});
	
	//Resize del aspecto
	var canvas = document.getElementById("gl-canvas");
	canvas.width = window.innerWidth
	canvas.height = window.innerHeight
	gl = WebGLUtils.setupWebGL(canvas);
	gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
		//Display controles
	var ctrls = document.getElementById("ctrls1");
	var distancia = parseInt(canvas.height * 0.85, 10);
	var pos = distancia.toString() + "px";
	ctrls.style.top = pos;
	ctrls = document.getElementById("ctrls2");
	distancia = distancia + 15;
	pos = distancia.toString() + "px";
	ctrls.style.top = pos;
	ctrls = document.getElementById("ctrls6");
	distancia = distancia + 15;
	pos = distancia.toString() + "px";
	ctrls.style.top = pos;
	ctrls = document.getElementById("ctrls3");
	distancia = distancia + 15;
	pos = distancia.toString() + "px";
	ctrls.style.top = pos;
	ctrls = document.getElementById("ctrls4");
	distancia = distancia + 15;
	pos = distancia.toString() + "px";
	ctrls.style.top = pos;
	ctrls = document.getElementById("ctrls5");
	distancia = distancia + 15;
	pos = distancia.toString() + "px";
	ctrls.style.top = pos;
	
		//Display tiempo
	var tiempo = document.getElementById("tiempo");
	distancia = parseInt(canvas.width * 0.9, 10);
	pos = distancia.toString() + "px";
	tiempo.style.left = pos;
	// disminuir el tiempo total en un segundo
    if (pararTiempo == false){
        tiempoTotal -= dt/1000;
        tiempoRestante = tiempoTotal.toFixed(2)
        if (tiempoTotal < 0 && gameOver == false ) {
            gameOver = true
            location.reload()
        }
        // actualizar el contenido del elemento HTML con el nuevo valor
        tiempo.innerHTML = "Tiempo restante: " + tiempoRestante + " segundos";
    }
    
}

//----------------------------------------------------------------------------
// Rendering Event Function
//----------------------------------------------------------------------------

function render(dt) {
	// Clear the buffer and draw everything
	gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);

	objectsToDraw.forEach(function(object) {
		gl.useProgram(object.programInfo.program);

		// Setup buffers and attributes
		setBuffersAndAttributes(object.programInfo, object);

		// Set the uniforms
		setUniforms(object.programInfo, object.uniforms);

		// Draw
		gl.drawArrays(object.primitive, 0, object.pointsArray.length);
	});
}

//----------------------------------------------------------------------------
// Utils functions
//----------------------------------------------------------------------------

function setPrimitive(objectsToDraw) {	
	
	objectsToDraw.forEach(function(object) {
		switch(object.primType) {
		  case "lines":
			object.primitive = gl.LINES;
			break;
		  case "line_strip":
			object.primitive = gl.LINE_STRIP;
			break;
		  case "triangles":
			object.primitive = gl.TRIANGLES;
			break;
		  default:
			object.primitive = gl.TRIANGLES;
		}
	});	
}	

function setUniforms(pInfo, uniforms) {
	var canvas = document.getElementById("gl-canvas");

	// Set up camera
	// Projection matrix
	projection = perspective( 45.0, canvas.width/canvas.height, 0.1, 100.0 );
	gl.uniformMatrix4fv( pInfo.uniformLocations.projection, gl.FALSE, projection ); // copy projection to uniform value in shader
	
	// View matrix (static cam)
	//eye = vec3(10.0, 0.0, 10.0);
	//target = vec3(0.0, 0.0, 0.0);
	//up = vec3(0.0, 0.0, 1.0);
	view = lookAt(eye,target,up);
	
	gl.uniformMatrix4fv(pInfo.uniformLocations.view, gl.FALSE, view); // copy view to uniform value in shader

	// Copy uniform model values to corresponding values in shaders
	if (pInfo.uniformLocations.baseColor != null) {
		gl.uniform4f(pInfo.uniformLocations.baseColor, uniforms.u_color[0], uniforms.u_color[1], uniforms.u_color[2], uniforms.u_color[3]);
	}
	gl.uniformMatrix4fv(pInfo.uniformLocations.model, gl.FALSE, uniforms.u_model);
}

function setBuffersAndAttributes(pInfo, object) {
	// Load the data into GPU data buffers
	// Vertices
	var vertexBuffer = gl.createBuffer();
	gl.bindBuffer( gl.ARRAY_BUFFER, vertexBuffer );
	gl.bufferData( gl.ARRAY_BUFFER,  flatten(object.pointsArray), gl.STATIC_DRAW );
	gl.vertexAttribPointer( pInfo.attribLocations.vPosition, 4, gl.FLOAT, gl.FALSE, 0, 0 );
	gl.enableVertexAttribArray( pInfo.attribLocations.vPosition );

	// Colors
	if (object.colorsArray != null) {
		var colorBuffer = gl.createBuffer();
		gl.bindBuffer( gl.ARRAY_BUFFER, colorBuffer );
		gl.bufferData( gl.ARRAY_BUFFER,  flatten( object.colorsArray), gl.STATIC_DRAW );
		gl.vertexAttribPointer( pInfo.attribLocations.vColor, 4, gl.FLOAT, gl.FALSE, 0, 0 );
		gl.enableVertexAttribArray( pInfo.attribLocations.vColor );
	}
}